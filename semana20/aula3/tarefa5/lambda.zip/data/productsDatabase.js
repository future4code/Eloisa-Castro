"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const baseDatabase_1 = require("./baseDatabase");
class ProductsDB extends baseDatabase_1.BaseDatabase {
    constructor() {
        super(...arguments);
        this.productsTableName = "products_aula203";
    }
    createProduct(product) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.connection.raw(`
    INSERT INTO ${this.productsTableName} (id, name, photo, price)
    VALUES (
      '${product.getId()}',
      '${product.getName()}',
      '${product.getPhoto()}',
      '${product.getPrice()}'
    )
    `);
        });
    }
}
exports.ProductsDB = ProductsDB;
