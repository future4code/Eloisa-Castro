"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const createProduct_1 = require("../../business/usecase/createProduct");
const productsDatabase_1 = require("../../data/productsDatabase");
exports.createProductEndpoint = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const createProductUC = new createProduct_1.CreateProductUC(new productsDatabase_1.ProductsDB());
        const result = yield createProductUC.execute({
            name: req.body.name,
            photo: req.body.photo,
            price: req.body.price,
        });
        res.status(200).send({
            message: "Product created succefully"
        });
    }
    catch (err) {
        res.status(err.errorCode || 400).send({
            message: err.message,
        });
    }
});
