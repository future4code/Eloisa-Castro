"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Products {
    constructor(id, name, photo, price) {
        this.id = id;
        this.name = name;
        this.photo = photo;
        this.price = price;
    }
    getId() {
        return this.id;
    }
    getName() {
        return this.name;
    }
    getPhoto() {
        return this.photo;
    }
    getPrice() {
        return this.price;
    }
}
exports.Products = Products;
