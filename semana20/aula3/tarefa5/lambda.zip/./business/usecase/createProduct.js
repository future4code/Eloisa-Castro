"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const uuid_1 = require("uuid");
const product_1 = require("../entities/product");
class CreateProductUC {
    constructor(productGateway) {
        this.productGateway = productGateway;
    }
    execute(input) {
        return __awaiter(this, void 0, void 0, function* () {
            const id = uuid_1.v4();
            if (!input.name || !input.photo || !input.price) {
                throw new Error("Invalid parameters");
            }
            const product = new product_1.Products(id, input.name, input.photo, input.price);
            yield this.productGateway.createProduct(product);
            return {
                id,
                name: input.name,
                photo: input.photo,
                price: input.price
            };
        });
    }
}
exports.CreateProductUC = CreateProductUC;
